# 🔧 Claude Code — Инструкция по восстановлению настроек (Windows)

## 📦 Что входит в бекап

```
claude_settings_backup/
├── global/                          # Глобальные настройки (~/.claude/)
│   ├── settings.json                # Разрешения, доп. директории
│   └── commands/                    # Глобальные slash-команды
│       ├── api-doc.md               # /api-doc — создание API документации
│       ├── research.md              # /research — глубокий поиск
│       └── review.md                # /review — ревью кода
│
├── project/                         # Настройки проекта (.claude/)
│   ├── settings.json                # Разрешения проекта
│   ├── settings.local.json          # Локальные разрешения + MCP + hooks
│   ├── commands/                    # Проектные slash-команды
│   │   ├── audit.md                 # /audit — аудит модуля
│   │   ├── bench.md                 # /bench — анализ бенчмарков
│   │   ├── comment.md               # /comment — добавить комментарии
│   │   ├── doc.md                   # /doc — документация модуля
│   │   └── optimizer.md             # /optimizer — оптимизация kernels
│   ├── agents/                      # Кастомные агенты
│   │   ├── benchmark-analyzer.md    # Анализатор бенчмарков
│   │   ├── gpu-optimizer.md         # Оптимизатор GPU kernels
│   │   ├── module-auditor.md        # Аудитор модулей
│   │   └── module-doc-writer.md     # Писатель документации
│   └── hooks/                       # PowerShell хуки
│       ├── on_stop.ps1              # Хук на завершение сессии
│       ├── pre_bash.ps1             # Защита от опасных команд
│       └── post_write.ps1           # Напоминание при изменении .cl файлов
│
└── RESTORE_INSTRUCTIONS.md          # Этот файл
```

---

## 🚀 Шаг 1 — Установка Claude Code

```powershell
# Установить Node.js (если нет) — https://nodejs.org
# Установить Claude Code глобально
npm install -g @anthropic-ai/claude-code

# Или через winget
winget install Anthropic.ClaudeCode
```

---

## 🔑 Шаг 2 — Авторизация

```powershell
# Войти через браузер
claude login

# Проверить
claude --version
```

---

## 📁 Шаг 3 — Восстановление глобальных настроек

```powershell
# Путь к глобальным настройкам Claude
$GlobalClaude = "$env:USERPROFILE\.claude"

# 1. Скопировать глобальный settings.json
Copy-Item "global\settings.json" "$GlobalClaude\settings.json" -Force

# 2. Скопировать глобальные команды
if (!(Test-Path "$GlobalClaude\commands")) {
    New-Item -ItemType Directory -Path "$GlobalClaude\commands"
}
Copy-Item "global\commands\*" "$GlobalClaude\commands\" -Force
```

> ⚠️ **Важно**: НЕ копируй `.credentials.json` — он привязан к конкретному аккаунту!

---

## 📁 Шаг 4 — Восстановление настроек проекта

```powershell
# Путь к папке проекта (измени на актуальный)
$ProjectRoot = "E:\C++\GPUWorkLib"
$ProjectClaude = "$ProjectRoot\.claude"

# 1. Создать структуру
New-Item -ItemType Directory -Path "$ProjectClaude\commands" -Force
New-Item -ItemType Directory -Path "$ProjectClaude\agents" -Force
New-Item -ItemType Directory -Path "$ProjectClaude\hooks" -Force

# 2. Скопировать настройки
Copy-Item "project\settings.json" "$ProjectClaude\settings.json" -Force

# settings.local.json — ТОЛЬКО если пути совпадают (см. предупреждение ниже)
# Copy-Item "project\settings.local.json" "$ProjectClaude\settings.local.json" -Force

# 3. Скопировать команды
Copy-Item "project\commands\*" "$ProjectClaude\commands\" -Force

# 4. Скопировать агентов
Copy-Item "project\agents\*" "$ProjectClaude\agents\" -Force

# 5. Скопировать хуки
Copy-Item "project\hooks\*" "$ProjectClaude\hooks\" -Force
```

---

## ⚙️ Шаг 5 — Настройка MCP серверов

MCP серверы регистрируются через CLI. Запусти в папке проекта:

```powershell
cd "E:\C++\GPUWorkLib"

# Sequential Thinking (сложная логика)
claude mcp add sequential-thinking -- npx -y @modelcontextprotocol/server-sequential-thinking

# Context7 (документация библиотек)
claude mcp add context7 -- npx -y @upstash/context7-mcp

# Memory (граф знаний)
claude mcp add memory -- npx -y @modelcontextprotocol/server-memory

# GitHub (поиск кода)
# ⚠️ Замени YOUR_TOKEN на свой GitHub Personal Access Token
# Создать токен: https://github.com/settings/tokens
claude mcp add github --scope user `
  -e GITHUB_PERSONAL_ACCESS_TOKEN=YOUR_TOKEN `
  -- npx -y @modelcontextprotocol/server-github

# DAP Debug (отладчик)
claude mcp add dap-debug -- npx -y @modelcontextprotocol/server-dap
```

### Проверка MCP серверов

```powershell
claude mcp list
claude mcp list --scope user
```

---

## ⚠️ Шаг 6 — Адаптация settings.local.json

Файл `settings.local.json` содержит **пути** — их нужно адаптировать:

### Что менять:

1. **Пути к Python**:
   ```
   "F:/Program Files (x86)/Python312/python.exe"
   "F:/Program Files (x86)/Python314/python.exe"
   ```
   → Замени на свой путь: `where python` покажет актуальный

2. **Пути к хукам**:
   ```
   "bash /home/alex/C++/GPUWorkLib/.claude/hooks/on_stop.sh"
   ```
   → На Windows: `powershell -File E:\C++\GPUWorkLib\.claude\hooks\on_stop.ps1`

3. **Пути к проекту**:
   ```
   "/home/alex/C++/GPUWorkLib"
   ```
   → Замени на `E:\C++\GPUWorkLib`

### Актуальный settings.local.json для Windows:

```json
{
  "permissions": {
    "allow": [
      "Bash(cmake --build*)",
      "Bash(cmake --preset*)",
      "Bash(cmake -B*)",
      "Bash(python3*)",
      "Bash(make*)",
      "Bash(ninja*)",
      "mcp__sequential-thinking__*",
      "mcp__context7__*",
      "mcp__memory__*",
      "mcp__dap-debug__get-call-stack",
      "mcp__dap-debug__evaluate-expression",
      "mcp__dap-debug__step-over",
      "mcp__dap-debug__step-into",
      "mcp__dap-debug__step-out",
      "mcp__dap-debug__continue",
      "mcp__dap-debug__get-debug-state",
      "mcp__dap-debug__get-variables-scope",
      "mcp__dap-debug__get-debug-console"
    ]
  },
  "enableAllProjectMcpServers": true,
  "hooks": {
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "powershell -File E:\\C++\\GPUWorkLib\\.claude\\hooks\\on_stop.ps1"
          }
        ]
      }
    ],
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "powershell -File E:\\C++\\GPUWorkLib\\.claude\\hooks\\pre_bash.ps1"
          }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "Write",
        "hooks": [
          {
            "type": "command",
            "command": "powershell -File E:\\C++\\GPUWorkLib\\.claude\\hooks\\post_write.ps1"
          }
        ]
      }
    ]
  }
}
```

---

## 🧪 Шаг 7 — Проверка

```powershell
cd "E:\C++\GPUWorkLib"

# Запустить Claude и проверить
claude

# Внутри сессии — проверить команды
/audit
/doc
/bench

# Проверить агентов (через Tool Use в коде)
# Должны появиться в system-reminder как доступные skills
```

---

## 📋 Список команд (slash commands)

| Команда | Область | Описание |
|---------|---------|----------|
| `/api-doc` | Глобальная | Создать API.md для модуля GPUWorkLib |
| `/research` | Глобальная | Глубокий поиск через sequential-thinking + context7 |
| `/review` | Глобальная | Ревью кода с лучшими практиками |
| `/audit` | Проект | Аудит модуля на соответствие эталону |
| `/bench` | Проект | Анализ GPUProfiler отчётов |
| `/comment` | Проект | Добавить смысловые комментарии |
| `/doc` | Проект | Создать/обновить Full.md документацию |
| `/optimizer` | Проект | Оптимизация HIP/ROCm/OpenCL ядер |

---

## 🤖 Список агентов (subagents)

| Агент | Описание |
|-------|----------|
| `benchmark-analyzer` | Анализ GPUProfiler JSON/Markdown отчётов |
| `gpu-optimizer` | Оптимизация HIP/ROCm/OpenCL kernels |
| `module-auditor` | Аудит модуля на соответствие эталону vector_algebra |
| `module-doc-writer` | Создание Full.md документации модулей |

---

## 🔗 Полезные ссылки

- Claude Code docs: https://docs.anthropic.com/claude/docs/claude-code
- MCP servers registry: https://github.com/modelcontextprotocol/servers
- Context7: https://github.com/upstash/context7
- Sequential Thinking: https://github.com/modelcontextprotocol/servers/tree/main/src/sequentialthinking

---

*Backup created: 2026-03-09*
*Project: GPUWorkLib (E:\C++\GPUWorkLib)*
