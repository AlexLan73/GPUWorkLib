/**
 * @file test_vector_ops.cpp
 * @brief Тест VectorOpsModule - демонстрация всех 6 операций
 * 
 * Сценарий: Создать вектор [0..1023], протестировать все операции
 * 
 * @author DrvGPU Team
 * @date 2026-02-03
 */

#include "drv_gpu.hpp"
#include "vector_ops_module.hpp"
#include <iostream>
#include <iomanip>
#include <vector>

namespace test_example_mat{
using namespace drv_gpu_lib;

void PrintVector(const std::string& name, const std::vector<float>& vec, size_t count = 5) {
    std::cout << name << ": [";
    for (size_t i = 0; i < std::min(count, vec.size()); ++i) {
        std::cout << std::fixed << std::setprecision(1) << vec[i];
        if (i < std::min(count, vec.size()) - 1) std::cout << ", ";
    }
    std::cout << ", ...]" << std::endl;
}

std::vector<float> CreateSequence(size_t n) {
    std::vector<float> vec(n);
    for (size_t i = 0; i < n; ++i) {
        vec[i] = static_cast<float>(i);
    }
    return vec;
}

int run() {
    std::cout << "\n════════════════════════════════════════════════════════════════════\n";
    std::cout << "  VectorOpsModule Test - Примитивные операции с векторами\n";
    std::cout << "════════════════════════════════════════════════════════════════════\n\n";
    
    try {
        std::cout << "🔧 Инициализация DrvGPU (OpenCL, device 0)...\n";
        DrvGPU gpu(BackendType::OPENCL, 0);
        gpu.Initialize();
        std::cout << "✅ DrvGPU initialized\n";
        std::cout << "   Device: " << gpu.GetDeviceName() << "\n\n";
        
        std::cout << "🔧 Создание VectorOpsModule...\n";
        auto module = std::make_shared<VectorOpsModule>(&gpu.GetBackend());
        module->Initialize();
        gpu.GetModuleRegistry().RegisterModule("VectorOps", module);
        std::cout << "✅ VectorOpsModule зарегистрирован\n\n";
        
        const size_t N = 1024;
        std::cout << "📊 Создание входного вектора [0, 1, 2, ..., " << (N-1) << "]\n";
        
        auto host_A = CreateSequence(N);
        PrintVector("A (host)", host_A, 5);
        std::cout << "\n";
        
        auto& mem_mgr = gpu.GetMemoryManager();
        auto gpu_A = mem_mgr.CreateBuffer<float>(host_A.data(), N);
        auto gpu_C1 = mem_mgr.CreateBuffer<float>(N);
        auto gpu_C2 = mem_mgr.CreateBuffer<float>(N);
        auto gpu_C3 = mem_mgr.CreateBuffer<float>(N);
        
        std::cout << "✅ GPU буферы выделены (4 буфера по " << N << " элементов)\n\n";
        
        std::cout << "════════════════════════════════════════════════════════════════\n";
        std::cout << "  ТЕСТ 1: Добавление скаляра (out-of-place)\n";
        std::cout << "  Операция: C1[] = A[] + 1\n";
        std::cout << "════════════════════════════════════════════════════════════════\n";
        module->AddOneOut(gpu_A, gpu_C1, N);
        auto result_C1 = gpu_C1->Read();
        PrintVector("C1 = A + 1", result_C1, 5);
        std::cout << "✅ Тест 1 завершён\n\n";
        
        std::cout << "════════════════════════════════════════════════════════════════\n";
        std::cout << "  ТЕСТ 2: Вычитание скаляра (out-of-place)\n";
        std::cout << "  Операция: C2[] = A[] - 1\n";
        std::cout << "════════════════════════════════════════════════════════════════\n";
        module->SubOneOut(gpu_A, gpu_C2, N);
        auto result_C2 = gpu_C2->Read();
        PrintVector("C2 = A - 1", result_C2, 5);
        std::cout << "✅ Тест 2 завершён\n\n";
        
        std::cout << "════════════════════════════════════════════════════════════════\n";
        std::cout << "  ТЕСТ 3: Добавление скаляра (in-place)\n";
        std::cout << "  Операция: A[] = A[] + 1\n";
        std::cout << "════════════════════════════════════════════════════════════════\n";
        module->AddOneInPlace(gpu_A, N);
        auto result_A_after_add = gpu_A->Read();
        PrintVector("A (после +1)", result_A_after_add, 5);
        std::cout << "✅ Тест 3 завершён\n\n";
        
        std::cout << "════════════════════════════════════════════════════════════════\n";
        std::cout << "  ТЕСТ 4: Вычитание скаляра (in-place)\n";
        std::cout << "  Операция: A[] = A[] - 1 (возвращаем к исходному)\n";
        std::cout << "════════════════════════════════════════════════════════════════\n";
        module->SubOneInPlace(gpu_A, N);
        auto result_A_after_sub = gpu_A->Read();
        PrintVector("A (после -1)", result_A_after_sub, 5);
        std::cout << "✅ Тест 4 завершён (A вернулось к [0, 1, 2, ...])\n\n";
        
        std::cout << "════════════════════════════════════════════════════════════════\n";
        std::cout << "  ТЕСТ 5: Сложение двух векторов (out-of-place)\n";
        std::cout << "  Операция: C3[] = C1[] + C2[]\n";
        std::cout << "  Ожидается: C3[i] = (A[i] + 1) + (A[i] - 1) = 2 * A[i]\n";
        std::cout << "════════════════════════════════════════════════════════════════\n";
        module->AddVectorsOut(gpu_C1, gpu_C2, gpu_C3, N);
        auto result_C3 = gpu_C3->Read();
        PrintVector("C3 = C1 + C2", result_C3, 5);
        std::cout << "✅ Тест 5 завершён\n\n";
        
        std::cout << "════════════════════════════════════════════════════════════════\n";
        std::cout << "  ТЕСТ 6: Сложение двух векторов (in-place)\n";
        std::cout << "  Операция: C3[] = C3[] + C2[]\n";
        std::cout << "════════════════════════════════════════════════════════════════\n";
        module->AddVectorsInPlace(gpu_C3, gpu_A, N);
        auto result_C1_final = gpu_C3->Read();
        PrintVector("C3 (после += C2)", result_C1_final, 5);
        std::cout << "✅ Тест 6 завершён\n\n";
        
        std::cout << "════════════════════════════════════════════════════════════════\n";
        std::cout << "✅ Все 6 тестов пройдены успешно!\n\n";
        
        mem_mgr.PrintStatistics();
        
        std::cout << "════════════════════════════════════════════════════════════════\n\n";
        
        return 0;
        
    } catch (const std::exception& e) {
        std::cerr << "\n❌ ОШИБКА: " << e.what() << "\n\n";
        return 1;
    }
}
}