# 📦 MCP Configuration Export Package

Этот пакет содержит полную конфигурацию MCP серверов для проекта **GPUWorkLib**.

## 📋 Содержимое пакета

1. **mcp_servers_config.json** - JSON конфигурация всех серверов
2. **import_mcp_config.sh** - Скрипт автоматической установки
3. **README.md** - Эта инструкция

## 🚀 Быстрая установка на новом компьютере

### Шаг 1: Скопируй проект GPUWorkLib

Убедись, что проект GPUWorkLib уже склонирован на новом компьютере:
```bash
cd ~
git clone git@github.com:твой-юзер/GPUWorkLib.git
cd GPUWorkLib
```

### Шаг 2: Запусти скрипт импорта

Из папки с проектом:
```bash
cd Doc/EXPORT_MCP_CONFIG
./import_mcp_config.sh
```

Или из любой папки, указав путь к проекту:
```bash
./import_mcp_config.sh /путь/к/GPUWorkLib
```

### Шаг 3: Проверь установку

```bash
claude mcp list
```

Должны быть подключены:
- ✓ sequential-thinking
- ✓ context7
- ✓ filesystem
- ✓ memory
- ⏳ sqlite (может требовать npm пакеты при первом запуске)
- ⏳ git (может требовать npm пакеты при первом запуске)
- ⏳ fetch (может требовать npm пакеты при первом запуске)

## 🔧 Ручная установка (если скрипт не работает)

### 1. Sequential Thinking
```bash
claude mcp add sequential-thinking -- npx -y @modelcontextprotocol/server-sequential-thinking
```

### 2. Context7
```bash
claude mcp add context7 -- npx -y @upstash/context7-mcp@latest
```

### 3. Filesystem
```bash
claude mcp add filesystem -- npx -y @modelcontextprotocol/server-filesystem /путь/к/GPUWorkLib
```

### 4. Memory
```bash
claude mcp add memory -- npx -y @modelcontextprotocol/server-memory
```

### 5. SQLite
```bash
touch /путь/к/GPUWorkLib/results.db
claude mcp add sqlite -- npx -y @modelcontextprotocol/server-sqlite --db-path /путь/к/GPUWorkLib/results.db
```

### 6. Git
```bash
claude mcp add git -- npx -y @modelcontextprotocol/server-git --repository /путь/к/GPUWorkLib
```

### 7. Fetch
```bash
claude mcp add fetch -- npx -y @modelcontextprotocol/server-fetch
```

## 📚 Дополнительные серверы

### GitHub MCP (опционально)
```bash
sudo apt install -y gh
gh auth login
export GITHUB_TOKEN=$(gh auth token)
claude mcp add github -e GITHUB_PERSONAL_ACCESS_TOKEN=$GITHUB_TOKEN -- npx -y @modelcontextprotocol/server-github
```

### Brave Search (опционально)
```bash
# Получить ключ: https://brave.com/search/api/
claude mcp add brave-search -e BRAVE_API_KEY=ваш_ключ -- npx -y @modelcontextprotocol/server-brave-search
```

## 🎯 Что делают серверы

### sequential-thinking
- Решение сложных задач через цепочки рассуждений
- Автоматически используется для трудных вопросов

### context7
- Поиск документации CUDA, ROCm, cuFFT, hipFFT
- Доступ к актуальной технической информации

### filesystem
- Расширенная работа с файлами проекта
- Чтение, запись, поиск в пределах проекта

### memory
- Постоянная память между сессиями
- Сохранение ключевых находок и паттернов

### sqlite
- Хранение результатов бенчмарков и тестов
- Анализ производительности RTX3060 vs MI100

### git
- Расширенная работа с git репозиторием
- История изменений, blame, diff

### fetch
- Загрузка документации и примеров кода
- Работа с внешними ресурсами

## 🖥️ Особенности для GPU проекта

Эта конфигурация оптимизирована для:
- **NVIDIA RTX 3060** (CUDA)
- **AMD MI100** (ROCm/HIP)

Context7 настроен для поиска:
- CUDA Toolkit Documentation
- cuFFT Library
- ROCm Documentation
- hipFFT Library
- GPU optimization guides

## 🔍 Где хранятся настройки

После установки конфигурация сохраняется в:
```
~/.claude.json
```

Секция для проекта:
```json
{
  "projects": {
    "/путь/к/GPUWorkLib": {
      "mcpServers": { ... }
    }
  }
}
```

## 💡 Полезные команды

### Просмотр серверов
```bash
claude mcp list
```

### Удаление сервера
```bash
claude mcp remove <name>
```

### Перезапуск сервера
```bash
claude mcp restart <name>
```

## 📖 Дополнительная документация

После установки проекта смотри:
- `Doc/MCP_SERVERS_SETUP.md` - Полное руководство
- `Doc/MCP_CHEATSHEET.md` - Быстрая шпаргалка
- `Doc/MANUAL_INSTALL_GITHUB_BRAVE.md` - Установка GitHub и Brave

## ❓ Проблемы и решения

### Серверы не подключаются
```bash
# Проверь список
claude mcp list

# Перезапусти сервер
claude mcp restart <name>

# Удали и добавь заново
claude mcp remove <name>
# ... затем добавь снова
```

### npm пакеты не устанавливаются
Серверы автоматически загружают нужные пакеты при первом использовании через `npx -y`.
Подожди несколько секунд при первом запросе.

### Путь к проекту изменился
Удали серверы `filesystem`, `git`, `sqlite` и добавь заново с новым путём:
```bash
claude mcp remove filesystem
claude mcp add filesystem -- npx -y @modelcontextprotocol/server-filesystem /новый/путь
```

## 🎉 Готово!

После установки можешь сразу работать с проектом через Claude Code!

Все MCP серверы автоматически активируются при обращении к ним.

---

**Создано**: 2026-02-05
**Проект**: GPUWorkLib
**GPU**: NVIDIA RTX 3060 + AMD MI100
**Автор**: Кодо 💕
