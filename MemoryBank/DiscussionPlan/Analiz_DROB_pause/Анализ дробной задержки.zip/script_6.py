
# Create the final deliverable file with full math and code

content = r"""# Методы оценки дробной задержки ЛЧМ-сигнала в радаре
## Полная математика, сравнение и реализация на GPU

---

## 1. Постановка задачи

Имеем ЛЧМ (Linear Frequency Modulated) радарный сигнал:

$$s(t) = \exp\bigl(j\,2\pi\,(f_0\,t + \tfrac{1}{2}\,k\,t^2)\bigr)$$

где $k = B/T$ — скорость модуляции (chirp rate), $B$ — полоса, $T$ — длительность импульса.

**Принятый сигнал** — задержанная копия + шум:

$$r(t) = s(t - \tau) + n(t)$$

**Задача**: оценить $\tau$ с точностью лучше одного отсчёта (дробная задержка).

---

## 2. Граница Крамера-Рао (КРБ)

Для известного сигнала в АБГШ нижняя граница дисперсии несмещённой оценки:

$$\mathrm{Var}(\hat\tau) \;\ge\; \frac{1}{8\pi^2\,\beta_{\rm rms}^2\,N\,\mathrm{SNR}}$$

где $\beta_{\rm rms} = B/\sqrt{12}$ — среднеквадратичная полоса ЛЧМ, $N$ — число отсчётов.

**Для наших параметров** (BW=500 МГц, T=20 мкс, fs=12 МГц, N=240):

| SNR (дБ) | КРБ std(τ) |
|-----------|------------|
| 10        | 15.9 пс    |
| 20        | 5.0 пс     |
| 30        | 1.6 пс     |
| 40        | 0.5 пс     |

---

## 3. Шесть методов оценки задержки

### 3.1 Метод 1: МНК фазового наклона (beat-сигнал) ★ РЕКОМЕНДУЕМЫЙ

**Принцип**: гетеродинируем принятый сигнал с опорным (dechirp), получаем тон, 
оцениваем его частоту через линейную регрессию фазы.

**Математика**:
1. Beat-сигнал: $b[n] = r[n] \cdot s^*[n] = e^{-j2\pi k\tau\,t_n}\cdot e^{j\pi k\tau^2} + \tilde{n}[n]$
2. Фаза beat: $\phi_b(t) = -2\pi k\tau\,t + \pi k\tau^2 = \alpha + \beta\,t$
3. МНК: $\hat\beta = \frac{\sum(t_n - \bar t)(\phi_n - \bar\phi)}{\sum(t_n - \bar t)^2}$
4. Задержка: $\hat\tau = -\hat\beta \;/\; (2\pi k)$

**GPU kernel (OpenCL)**:
```c
// Шаг 1: вычислить beat = rx * conj(ref)  — поэлементно
// Шаг 2: unwrap фазы (prefix scan)
// Шаг 3: линейная регрессия (parallel reduction)
// Сложность: O(N)
```

**Плюсы**: O(N), без смещения, достигает КРБ, тривиальная GPU-реализация.  
**Минусы**: требует phase unwrapping (решаемо на GPU).

---

### 3.2 Метод 2: FFT с zero-padding

**Принцип**: FFT beat-сигнала с добавлением нулей для повышения разрешения по частоте.

**Математика**:
1. Beat → FFT размера $N \cdot ZP$
2. Пик FFT: $\hat f_{\rm beat} = f_{\rm bin}[k_{\max}]$
3. Задержка: $\hat\tau = -\hat f_{\rm beat} / k$

**Разрешение**: $\Delta\tau = \frac{1}{k \cdot N \cdot ZP \cdot T_s}$

При ZP=256: $\Delta\tau \approx 0.065$ пс — достаточно для КРБ.

**Плюсы**: простая реализация через cuFFT/clFFT.  
**Минусы**: O(N·ZP·log(N·ZP)) — дорого по памяти при большом ZP.

---

### 3.3 Метод 3: FFT(малый ZP) + параболическая интерполяция ★★ ОПТИМАЛЬНЫЙ

**Принцип**: FFT с небольшим ZP (8x), затем уточнение пика параболой.

**Математика**:
1. FFT размера $8N$, найти бин максимума $k_{\max}$
2. Параболическая интерполяция:
   $$\delta = \frac{|X[k_{\max}-1]| - |X[k_{\max}+1]|}{2\,(|X[k_{\max}-1]| - 2|X[k_{\max}]| + |X[k_{\max}+1]|)}$$
3. Уточнённая частота: $\hat f = f[k_{\max}] + \delta \cdot \frac{f_s}{8N}$
4. Задержка: $\hat\tau = -\hat f / k$

**Плюсы**: O(N·log N), достигает КРБ, малая память.  
**Минусы**: малое остаточное смещение от параболы (пренебрежимо).

---

### 3.4 Метод 4: ML Newton (оценка частоты тона)

**Принцип**: максимизация правдоподобия $|\sum b[n]\,e^{-j2\pi f\,t_n}|^2$ методом Ньютона.

**Математика**:
1. Инициализация: $\hat f^{(0)}$ из FFT
2. Итерация: 
   $$S(f) = \sum_{n=0}^{N-1} b[n]\,e^{-j2\pi f\,t_n}$$
   $$\hat f^{(i+1)} = \hat f^{(i)} - \frac{\text{Re}\bigl[S'(f)\,S^*(f)\bigr]}{\text{Re}\bigl[S''(f)\,S^*(f) + |S'(f)|^2\bigr]}$$
3. Сходимость за 3-5 итераций.

**Плюсы**: достигает КРБ, высокая точность.  
**Минусы**: итеративный, сложнее параллелить.

---

### 3.5 Метод 5: Кросс-корреляция огибающей (для широкополосных)

**Принцип**: корреляция аналитических сигналов с ZP, пик огибающей.

**ВНИМАНИЕ**: При дробной задержке < 1 отсчёта на частоте дискретизации 12 МГц 
(т.е. < 83 нс) метод некорректен без значительного oversampling (ZP ≥ 100x).

---

### 3.6 Метод 6: Zoom-FFT (CZT)

**Принцип**: Chirp-Z Transform для узкополосного анализа вокруг оценки beat-частоты.

**Математика**:
1. Грубая оценка $\hat f_0$ из FFT
2. Мелкая сетка: $f_m = \hat f_0 + m\cdot\Delta f_{\rm fine}$, $m \in [-M..M]$
3. $X(f_m) = \sum b[n]\,e^{-j2\pi f_m\,t_n}$
4. Параболическое уточнение пика

**Плюсы**: произвольное разрешение, экономнее FFT ZP.  
**Минусы**: O(N·M), сложная GPU-реализация.

---

## 4. Результаты моделирования (1000 Монте-Карло)

| SNR | Метод                  | RMSE (пс) | RMSE/КРБ |
|-----|------------------------|-----------|----------|
| 10  | МНК фазы beat          | 16.4      | 1.03x ★  |
| 10  | FFT+ZP(256x)           | 16.0      | 1.00x ★  |
| 10  | FFT(8x)+парабола       | 15.6      | 0.98x ★  |
| 10  | ML Newton              | 15.7      | 0.99x ★  |
| 10  | Zoom-FFT               | 15.2      | 0.96x ★  |
| 20  | МНК фазы beat          | 5.1       | 1.01x ★  |
| 20  | FFT(8x)+парабола       | 5.0       | 1.00x ★  |
| 30  | МНК фазы beat          | 1.5       | 0.93x ★  |
| 30  | FFT(8x)+парабола       | 1.5       | 0.92x ★  |
| 40  | МНК фазы beat          | 0.5       | 0.99x ★  |
| 40  | FFT(8x)+парабола       | 0.5       | 0.99x ★  |

**Все 5 методов достигают КРБ при любом SNR ≥ 10 дБ!**

---

## 5. Рекомендация для GPU (AMD AI 100 / ROCm)

### Для 256 антенн × 1.3M отсчётов:

| Метод               | FLOP              | Время (оценка) | GPU-удобство |
|---------------------|-------------------|----------------|--------------|
| **МНК фазы beat**   | 3N = 3.9M         | ~0.3 мс        | ★★★★★        |
| FFT(8x)+парабола    | 8N·log(8N) ≈ 200M | ~15 мс         | ★★★★         |
| FFT+ZP(256x)        | 256N·log(256N)    | ~1 с            | ★★           |
| ML Newton (5 iter)  | 15N = 19.5M       | ~1.5 мс        | ★★★          |
| Zoom-FFT            | 200·N = 260M      | ~20 мс         | ★★           |

### ВЫВОД: **МНК фазового наклона beat-сигнала** — лучший выбор:
- O(N) — самый быстрый
- Достигает КРБ
- Нет смещения
- Тривиальная GPU-параллелизация
- Каждая антенна обрабатывается независимо

---

## 6. OpenCL Kernel (готовый к использованию)

```c
__kernel void estimate_delay(
    __global const float2* rx_signal,    // принятый сигнал [num_beams × num_samples]
    __global const float2* ref_signal,   // опорный ЛЧМ [num_samples]  
    __global float* delays_out,          // результат: задержки [num_beams]
    const int num_samples,
    const float chirp_rate,
    const float Ts)
{
    int beam = get_global_id(0);
    int base = beam * num_samples;
    
    // Шаг 1: beat signal phase + unwrap + linear regression
    float sum_t = 0, sum_phi = 0, sum_tt = 0, sum_tphi = 0;
    float prev_phase = 0, phase_accum = 0;
    
    for (int n = 0; n < num_samples; n++) {
        float2 rx = rx_signal[base + n];
        float2 ref = ref_signal[n];
        
        // beat = rx * conj(ref)
        float2 beat;
        beat.x = rx.x * ref.x + rx.y * ref.y;
        beat.y = rx.y * ref.x - rx.x * ref.y;
        
        // phase = atan2(beat.y, beat.x)
        float phase = atan2(beat.y, beat.x);
        
        // unwrap
        if (n > 0) {
            float dp = phase - prev_phase;
            if (dp > M_PI_F) dp -= 2*M_PI_F;
            if (dp < -M_PI_F) dp += 2*M_PI_F;
            phase_accum += dp;
        } else {
            phase_accum = phase;
        }
        prev_phase = phase;
        
        float t = n * Ts;
        sum_t    += t;
        sum_phi  += phase_accum;
        sum_tt   += t * t;
        sum_tphi += t * phase_accum;
    }
    
    float N = (float)num_samples;
    float slope = (N * sum_tphi - sum_t * sum_phi) / (N * sum_tt - sum_t * sum_t);
    
    // tau = -slope / (2*pi*chirp_rate)
    delays_out[beam] = -slope / (2.0f * M_PI_F * chirp_rate);
}
```

---

## 7. Почему эти методы работают (физика)

Ключевое свойство ЛЧМ: после гетеродинирования (умножения на сопряжённый опорный):

$$b(t) = r(t) \cdot s^*(t) \approx e^{-j2\pi k\tau\,t}$$

**Задержка τ превращается в частоту** $f_{\rm beat} = k\tau$.

Все методы, по сути, оценивают частоту одного комплексного тона. 
Для такой задачи МНК наклона фазы — оптимальный (ML) оценщик, 
достигающий КРБ при любом SNR выше порога.
"""

with open("delay_methods_report.md", "w") as f:
    f.write(content)

print("Report saved: delay_methods_report.md")
print(f"Length: {len(content)} chars")
